package com.example.david.project6;

import android.graphics.Color;
import android.graphics.Typeface;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Typeface customFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //customFont = new Typeface();
    }

    public void changeColor(View v)
    {
        Random rand = new Random();
        int rVal = rand.nextInt(255);
        int gVal = rand.nextInt(255);
        int bVal = rand.nextInt(255);

        int rValInv = 255 - rVal;
        int gValInv = 255 - gVal;
        int bValInv = 255 - bVal;

        TextView tvH = (TextView) findViewById(R.id.textViewH);
        TextView tvW = (TextView) findViewById(R.id.textViewW);

        tvH.setTextColor(Color.rgb(rVal, gVal, bVal));
        tvW.setTextColor(Color.rgb(rVal, gVal, bVal));

        ConstraintLayout rl = (ConstraintLayout) findViewById(R.id.viewPane);
        rl.setBackgroundColor(Color.rgb(rValInv, gValInv, bValInv));
    }


}
